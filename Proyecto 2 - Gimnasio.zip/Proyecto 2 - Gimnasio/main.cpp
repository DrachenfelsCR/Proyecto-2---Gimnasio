#include "tools.h"
#include "gym.h"
#include "measurements.h"
#include "routine.h"
#include "instructor.h"
#include "associate.h"
#include <time.h>
#include <cstdlib>
#include <iostream>
using namespace std;

int main() {

	gym g;
	g.controlSistema();
	return 0;
}